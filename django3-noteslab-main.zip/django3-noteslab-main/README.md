# NotesLab
I got bored and decided to practice some django with this simple note taking app.
With this app, users can write, save, edit,and delete notes easily.

Contributions (feedback, code contributions, etc.) are welcome.
